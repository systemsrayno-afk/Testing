import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

import live_engine
import main
import paper_trading as pt


def uptrend(n=80, last_high=None):
    idx = pd.date_range("2025-01-01 09:15", periods=n, freq="5min", tz="Asia/Kolkata")
    c = np.array([100 + i * 0.2 for i in range(n)])
    return pd.DataFrame({"Open": c, "High": c + 1, "Low": c - 1, "Close": c, "Volume": 1000}, index=idx)


def downtrend(n=80):
    df = uptrend(n)
    for col in ("Open", "High", "Low", "Close"):
        df[col] = 200 - (df[col] - 100)
    return df


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(pt, "LEDGER_PATH", tmp_path / "ledger.json")
    monkeypatch.setattr(main, "fetch_history", lambda *a, **k: uptrend())
    monkeypatch.setattr(live_engine, "fetch_history", lambda *a, **k: uptrend())
    return TestClient(main.app)


def test_health_static_and_no_source_leak(client):
    assert client.get("/api/health").json()["mode"] == "LIVE_TESTING_PAPER_ONLY"
    assert client.get("/").status_code == 200 and client.get("/paper.html").status_code == 200
    assert client.get("/main.py").status_code == 404


def test_analyze_and_candles(client):
    a = client.get("/api/analyze?symbol=RELIANCE").json()
    assert a["signal"] == "BUY" and a["provider_symbol"] == "RELIANCE.NS"
    assert client.get("/api/candles?symbol=RELIANCE&limit=50").json()["count"] == 50


def test_open_from_signal_then_duplicate_blocked(client):
    r = client.post("/api/paper/open-from-signal", json={"symbol": "RELIANCE"}).json()
    assert r["opened"] and r["trade"]["side"] == "BUY" and r["trade"]["quantity"] > 0
    again = client.post("/api/paper/open-from-signal", json={"symbol": "RELIANCE"}).json()
    assert again["opened"] is False and "already" in again["reason"]


def test_hold_signal_opens_nothing(client, monkeypatch):
    flat = uptrend(); flat[["Open", "High", "Low", "Close"]] = 100.0
    monkeypatch.setattr(live_engine, "fetch_history", lambda *a, **k: flat)
    r = client.post("/api/paper/open-from-signal", json={"symbol": "RELIANCE"}).json()
    assert r["opened"] is False and r["signal"] == "HOLD"


def test_positions_mark_to_market_then_auto_close_on_target(client, monkeypatch):
    client.post("/api/paper/open-from-signal", json={"symbol": "RELIANCE"})
    pos = client.get("/api/paper/positions").json()["positions"][0]
    assert pos["status"] == "OPEN" and "unrealized_pnl" in pos
    # a later candle spikes through the target -> position must auto-close at the target
    trade = pt.list_trades("OPEN")[0]
    later = uptrend(); ts = (pd.Timestamp.now(tz="UTC") + pd.Timedelta(minutes=5)).tz_convert("Asia/Kolkata")
    spike = pd.DataFrame({"Open": [trade["entry"]], "High": [trade["target"] + 1], "Low": [trade["entry"]],
                          "Close": [trade["target"]], "Volume": [1]}, index=[ts])
    monkeypatch.setattr(live_engine, "fetch_history", lambda *a, **k: pd.concat([later, spike]))
    out = client.get("/api/paper/positions").json()["positions"][0]
    assert out["status"] == "CLOSED" and out["exit_reason"] == "target" and out["pnl"] > 0
    assert client.get("/api/paper/ledger").json()["closed_trades"] == 1


def test_manual_close_and_reset_needs_confirm(client):
    t = client.post("/api/paper/open-from-signal", json={"symbol": "TCS"}).json()["trade"]
    assert client.post("/api/paper/close", json={"id": t["id"]}).json()["status"] == "CLOSED"
    assert client.post("/api/paper/close", json={"id": t["id"]}).status_code == 400
    assert client.post("/api/paper/reset", json={}).status_code == 400
    assert client.post("/api/paper/reset", json={"confirm": True}).status_code == 200


def test_bad_symbol_error_is_400_not_500(client, monkeypatch):
    def boom(*a, **k): raise ValueError("No data returned")
    monkeypatch.setattr(main, "fetch_history", boom)
    assert client.get("/api/analyze?symbol=NOPE").status_code == 400


def test_dashboard_does_not_destroy_its_own_price_child_element():
    """Regression: setting #headlineprice.textContent deleted the nested #pricedelta, so the next
    line threw 'Cannot set properties of null' and the signal/chart never rendered."""
    html = (main.ROOT / "static" / "index.html").read_text(encoding="utf-8")
    assert 'id="pricedelta"' in html
    assert '$("headlineprice").textContent' not in html


# ---------- live snapshot ----------
def _long_uptrend(n=300):
    idx = pd.date_range(end=pd.Timestamp.now(tz="UTC").floor("min"), periods=n, freq="5min")
    c = np.array([100 + i * 0.2 for i in range(n)])
    return pd.DataFrame({"Open": c, "High": c + 1, "Low": c - 1, "Close": c, "Volume": 1000}, index=idx)


@pytest.fixture()
def live(tmp_path, monkeypatch):
    main._cache.clear()
    calls = {"n": 0}
    def fetch(*a, **k):
        calls["n"] += 1
        return _long_uptrend()
    monkeypatch.setattr(main, "fetch_history", fetch)
    monkeypatch.setattr(main, "get_live_quote", lambda *a, **k: None)
    return TestClient(main.app), calls


def test_snapshot_returns_everything_in_one_request(live):
    c, _ = live
    d = c.get("/api/snapshot?symbol=RELIANCE&interval=5m&limit=100").json()
    assert d["analysis"]["signal"] == "BUY" and d["candles"]["count"] == 100
    assert d["quote_applied"] is False and d["stale"] is False and d["age_minutes"] < 6


def test_indicators_are_warmed_up_on_full_history_not_just_the_visible_tail(live):
    """Regression: EMAs were computed on only the last 100 candles, so lines started pinned to price."""
    c, _ = live
    first = c.get("/api/snapshot?limit=100").json()["candles"]["candles"][0]
    assert abs(first["ema21"] - first["close"]) > 1.0


def test_live_quote_moves_last_candle_but_bad_quote_is_ignored(live, monkeypatch):
    c, _ = live
    last_close = _long_uptrend()["Close"].iloc[-1]
    monkeypatch.setattr(main, "get_live_quote", lambda *a, **k: {"price": last_close + 1.0, "source": "t"})
    main._cache.clear()
    d = c.get("/api/snapshot").json()
    assert d["quote_applied"] and d["price"] == pytest.approx(last_close + 1.0, abs=0.01)
    assert d["candles"]["candles"][-1]["close"] == pytest.approx(last_close + 1.0, abs=0.01)
    monkeypatch.setattr(main, "get_live_quote", lambda *a, **k: {"price": last_close * 1.5, "source": "t"})
    main._cache.clear()
    d = c.get("/api/snapshot").json()
    assert d["quote_applied"] is False and d["price"] == pytest.approx(last_close, abs=0.01)


def test_rapid_requests_share_one_provider_call_then_refetch_after_ttl(live, monkeypatch):
    c, calls = live
    for _ in range(5):
        c.get("/api/snapshot?symbol=TCS")
    assert calls["n"] == 1
    monkeypatch.setattr(main, "CACHE_TTL", 0)
    c.get("/api/snapshot?symbol=TCS")
    assert calls["n"] == 2


def test_stale_feed_is_flagged_and_errors_are_400(live, monkeypatch):
    c, _ = live
    old = _long_uptrend(); old.index = old.index - pd.Timedelta(days=2)
    monkeypatch.setattr(main, "fetch_history", lambda *a, **k: old)
    main._cache.clear()
    assert c.get("/api/snapshot").json()["stale"] is True
    def boom(*a, **k): raise ValueError("No data returned")
    monkeypatch.setattr(main, "fetch_history", boom)
    main._cache.clear()
    assert c.get("/api/snapshot?symbol=NOPE").status_code == 400


def test_dashboard_has_live_controls_and_single_request_loader():
    html = (main.ROOT / "static" / "index.html").read_text(encoding="utf-8")
    assert 'id="livetoggle"' in html and 'id="livefreq"' in html and 'id="liveinfo"' in html
    assert "/api/snapshot" in html and "AbortController" in html
