import numpy as np
import pandas as pd
from indicators import add_indicators, analyze_frame


def sample_data(n=80):
    idx = pd.date_range("2025-01-01 09:15", periods=n, freq="5min")
    close = [100 + i * 0.2 for i in range(n)]
    return pd.DataFrame({"Open": close, "High": [x + 1 for x in close], "Low": [x - 1 for x in close],
                         "Close": close, "Volume": [1000] * n}, index=idx)


def test_indicators_added():
    result = add_indicators(sample_data())
    for name in ["EMA9", "EMA21", "RSI14", "MACD", "MACDSignal", "ATR14", "VWAP", "Support", "Resistance"]:
        assert name in result.columns
    assert len(result) == 80


def test_rsi_is_100_on_pure_uptrend_and_signal_is_buy():
    df = sample_data()
    assert add_indicators(df)["RSI14"].iloc[-1] == 100.0
    result = analyze_frame(df)
    assert result["signal"] == "BUY" and result["quantity"] > 0 and result["risk_budget"] == 125.0


def test_rsi_neutral_on_flat_prices():
    idx = pd.date_range("2025-01-01", periods=40, freq="5min")
    flat = pd.DataFrame({"Open": 100.0, "High": 100.0, "Low": 100.0, "Close": 100.0, "Volume": 10}, index=idx)
    assert add_indicators(flat)["RSI14"].iloc[-1] == 50.0


def test_vwap_resets_each_day():
    idx = list(pd.date_range("2025-01-01 09:15", periods=5, freq="5min")) + list(pd.date_range("2025-01-02 09:15", periods=5, freq="5min"))
    px = [100.0] * 5 + [200.0] * 5
    df = pd.DataFrame({"Open": px, "High": px, "Low": px, "Close": px, "Volume": 1000}, index=idx)
    assert add_indicators(df)["VWAP"].iloc[5] == 200.0


def test_insufficient_data_rejected():
    try:
        analyze_frame(sample_data(10))
    except ValueError as exc:
        assert "30 candles" in str(exc)
    else:
        raise AssertionError("Expected insufficient-data validation")
