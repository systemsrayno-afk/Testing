import pandas as pd
import pytest
import paper_trading as pt


@pytest.fixture(autouse=True)
def ledger(tmp_path, monkeypatch):
    monkeypatch.setattr(pt, "LEDGER_PATH", tmp_path / "ledger.json")


def candles(rows, start="2099-01-01 09:15"):
    idx = pd.date_range(start, periods=len(rows), freq="5min", tz="UTC")
    return pd.DataFrame([{"Open": r[0], "High": r[1], "Low": r[2], "Close": r[3]} for r in rows], index=idx)


def test_open_validates_levels_and_side():
    with pytest.raises(ValueError):
        pt.open_trade("X", "BUY", 10, 100, 105, 110)       # stop above entry
    with pytest.raises(ValueError):
        pt.open_trade("X", "SELL", 10, 100, 95, 90)        # stop below entry for a short
    with pytest.raises(ValueError):
        pt.open_trade("X", "HOLD", 10, 100, 95, 110)
    with pytest.raises(ValueError):
        pt.open_trade("X", "BUY", 0, 100, 95, 110)


def test_ledger_persists_and_has_open_is_case_insensitive():
    t = pt.open_trade("reliance", "BUY", 10, 100, 95, 110)
    assert pt.has_open("RELIANCE") and pt.list_trades("OPEN")[0]["id"] == t["id"]


def test_close_computes_pnl_with_costs_for_long_and_short():
    t = pt.open_trade("A", "BUY", 10, 100, 95, 110)
    c = pt.close_trade(t["id"], 110, "target")
    assert c["pnl"] == pytest.approx(100 - 0.0003 * (100 + 110) * 10, abs=0.01)
    s = pt.open_trade("B", "SELL", 10, 100, 105, 90)
    assert pt.close_trade(s["id"], 90, "target")["pnl"] > 0
    with pytest.raises(ValueError):
        pt.close_trade(t["id"], 100, "again")               # cannot double-close


def test_check_exit_stop_target_and_ignores_older_candles():
    t = pt.open_trade("A", "BUY", 10, 100, 95, 110)
    t["opened_at"] = "2099-01-01T09:20:00+00:00"
    rows = [(100, 120, 90, 100),     # 09:15 - BEFORE the trade opened: must be ignored
            (100, 105, 99, 102),     # 09:20 - not strictly after open: ignored
            (102, 104, 98, 100),     # 09:25 - nothing
            (100, 111, 99, 110)]     # 09:30 - target
    price, reason, _ = pt.check_exit(t, candles(rows))
    assert (price, reason) == (110.0, "target")
    assert pt.check_exit(t, candles(rows[:3])) is None


def test_stop_wins_if_both_touched_and_short_side_mirrors():
    t = pt.open_trade("A", "BUY", 10, 100, 95, 110)
    t["opened_at"] = "2099-01-01T09:00:00+00:00"
    assert pt.check_exit(t, candles([(100, 112, 94, 100)]))[1] == "stop"
    s = pt.open_trade("B", "SELL", 10, 100, 105, 90)
    s["opened_at"] = "2099-01-01T09:00:00+00:00"
    assert pt.check_exit(s, candles([(100, 101, 89, 95)]))[:2] == (90.0, "target")
    assert pt.check_exit(s, candles([(100, 106, 99, 100)]))[:2] == (105.0, "stop")


def test_stats():
    a = pt.open_trade("A", "BUY", 10, 100, 95, 110); pt.close_trade(a["id"], 110, "target")
    b = pt.open_trade("B", "BUY", 10, 100, 95, 110); pt.close_trade(b["id"], 95, "stop")
    s = pt.stats()
    assert s["closed_trades"] == 2 and s["win_rate_pct"] == 50.0 and s["profit_factor"] is not None
    pt.reset(); assert pt.stats()["closed_trades"] == 0
