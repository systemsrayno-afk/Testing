import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

import main
import paper_trading as pt
import strategy_check as sc


def frame(kind="up", n=80, end="2099-01-01 10:00"):
    idx = pd.date_range(end=end, periods=n, freq="5min", tz="UTC")
    base = np.arange(n) * 0.2
    c = 100 + base if kind == "up" else 200 - base if kind == "down" else np.full(n, 100.0)
    return pd.DataFrame({"Open": c, "High": c + 1, "Low": c - 1, "Close": c, "Volume": 1000}, index=idx)


NOW = pd.Timestamp("2099-01-01 10:02", tz="UTC")


def test_buy_all_rules_pass_and_stale_flag():
    r = sc.check_frame(frame("up"), "5m", now=NOW)
    assert r["signal"] == "BUY" and r["buy_score"] == 3 and r["stale"] is False and r["age_minutes"] == 2.0
    assert all(x["buy"] for x in r["rules"] if x["required"])
    old = sc.check_frame(frame("up"), "5m", now=NOW + pd.Timedelta(hours=5))
    assert old["stale"] is True and any("old" in n for n in old["notes"])


def test_sell_hold_and_ongoing_signal_note():
    assert sc.check_frame(frame("down"), "5m", now=NOW)["signal"] == "SELL"
    h = sc.check_frame(frame("flat"), "5m", now=NOW)
    assert h["signal"] == "HOLD" and h["fresh"] is False
    up = sc.check_frame(frame("up"), "5m", now=NOW)
    assert up["bars_in_signal"] > 1 and any("fresh trigger" in n for n in up["notes"])


def test_fresh_signal_detected_on_the_trigger_candle():
    n = 70
    c = np.r_[np.linspace(100, 90, 60), np.linspace(90, 96, n - 60)]
    idx = pd.date_range(end="2099-01-01 10:00", periods=n, freq="5min", tz="UTC")
    d = pd.DataFrame({"Open": c, "High": c + .2, "Low": c - .2, "Close": c, "Volume": 1}, index=idx)
    fresh = [sc.check_frame(d.iloc[:k], "5m", now=NOW)["fresh"] for k in range(61, n + 1)]
    assert any(fresh) and sum(fresh) == 1          # fires exactly once, on the first candle of the move


def test_scan_survives_bad_symbol_and_sorts_signals_first():
    def fetch(sym, *a):
        if sym == "BAD": raise ValueError("No data returned")
        return frame({"UP": "up", "DOWN": "down", "FLAT": "flat"}[sym])
    out = sc.scan(["FLAT", "BAD", "UP", "DOWN"], fetch=fetch)
    assert [x["symbol"] for x in out] == ["UP", "DOWN", "FLAT", "BAD"] and "error" in out[-1]
    assert len(sc.scan([f"S{i}" for i in range(30)], fetch=lambda *a: frame())) == 15       # capped


@pytest.fixture()
def ledger(tmp_path, monkeypatch):
    monkeypatch.setattr(pt, "LEDGER_PATH", tmp_path / "l.json")


def add(pnl_price, reason="target", side="BUY"):
    t = pt.open_trade("A", side, 10, 100, 95, 110)
    pt.close_trade(t["id"], pnl_price, reason)


def test_health_no_data_too_early_and_verdicts(ledger):
    assert sc.performance_health()["verdict"] == "NO_DATA"
    add(110); add(95, "stop")
    h = sc.performance_health()
    assert h["verdict"] == "TOO_EARLY" and "18 more" in h["message"]
    for _ in range(9): add(110)
    for _ in range(9): add(95, "stop")
    h = sc.performance_health()
    assert h["closed_trades"] == 20 and h["verdict"] == "HEALTHY" and h["exit_reasons"] == {"target": 10, "stop": 10}
    assert h["max_drawdown"] > 0 and 0 < h["breakeven_win_rate_pct"] < 50


def test_health_failing_when_losing(ledger):
    for _ in range(8): add(95, "stop")
    for _ in range(12): add(95, "stop")
    assert sc.performance_health()["verdict"] == "FAILING"


def test_api_endpoints(ledger, monkeypatch):
    monkeypatch.setattr(sc, "fetch_history", lambda *a, **k: frame("up"))
    c = TestClient(main.app)
    r = c.get("/api/strategy-check?symbols=RELIANCE,TCS").json()
    assert len(r["results"]) == 2 and r["results"][0]["signal"] == "BUY"
    assert c.get("/api/strategy-check?interval=1y").status_code == 400
    assert c.get("/api/strategy-health").json()["verdict"] == "NO_DATA"
    assert c.get("/check.html").status_code == 200
