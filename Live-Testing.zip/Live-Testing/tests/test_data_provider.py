import io
import urllib.error
import urllib.request

import pandas as pd
import pytest
from fastapi.testclient import TestClient

import data_provider as dp
import main


def payload(n=40, with_gap=True):
    base = 1_760_000_000
    ts = [base + i * 300 for i in range(n)]
    close = [1200.0 + i for i in range(n)]
    q = {"open": list(close), "high": [c + 1 for c in close], "low": [c - 1 for c in close],
         "close": list(close), "volume": [1000] * n}
    if with_gap:                                   # Yahoo pads missing candles with nulls
        for k in q:
            q[k][5] = None
    return {"meta": {"exchangeTimezoneName": "Asia/Kolkata", "regularMarketPrice": 1234.5},
            "timestamp": ts, "indicators": {"quote": [q]}}


class BrokenTicker:
    """Mimics the old-yfinance crash from the screenshot."""
    def __init__(self, *a, **k): pass
    def history(self, *a, **k): raise KeyError("tradingPeriods")
    @property
    def fast_info(self): raise KeyError("tradingPeriods")


def test_frame_from_chart_drops_null_padding_and_uses_exchange_timezone():
    df = dp._frame_from_chart(payload())
    assert len(df) == 39 and str(df.index.tz) == "Asia/Kolkata"
    assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"] and not df.isna().any().any()


def test_empty_chart_is_a_clear_error():
    with pytest.raises(ValueError, match="empty candle list"):
        dp._frame_from_chart({"meta": {}, "timestamp": [], "indicators": {"quote": [{}]}})


def test_keyerror_tradingperiods_falls_back_to_direct_yahoo(monkeypatch):
    monkeypatch.setattr(dp.yf, "Ticker", BrokenTicker)
    monkeypatch.setattr(dp, "_chart_json", lambda *a, **k: payload())
    df = dp.fetch_history("RELIANCE", "5d", "5m")
    assert len(df) == 39 and df["Close"].iloc[-1] == 1239.0


def test_empty_yfinance_result_also_falls_back(monkeypatch):
    class Empty(BrokenTicker):
        def history(self, *a, **k): return pd.DataFrame()
    monkeypatch.setattr(dp.yf, "Ticker", Empty)
    monkeypatch.setattr(dp, "_chart_json", lambda *a, **k: payload())
    assert len(dp.fetch_history("TCS", "5d", "5m")) == 39


def test_both_paths_failing_gives_actionable_message(monkeypatch):
    monkeypatch.setattr(dp.yf, "Ticker", BrokenTicker)
    def down(*a, **k): raise ValueError("Yahoo returned HTTP 429 (rate limited, wait a minute).")
    monkeypatch.setattr(dp, "_chart_json", down)
    with pytest.raises(ValueError) as e:
        dp.fetch_history("RELIANCE", "5d", "5m")
    msg = str(e.value)
    assert "429" in msg and "KeyError" in msg and "pip install -U yfinance" in msg


def test_http_429_is_explained(monkeypatch):
    def boom(*a, **k): raise urllib.error.HTTPError("u", 429, "Too Many", {}, io.BytesIO(b""))
    monkeypatch.setattr(urllib.request, "urlopen", boom)
    with pytest.raises(ValueError, match="rate limited"):
        dp._chart_json("X.NS", 5, "5m")


def test_live_quote_falls_back_to_chart_meta_then_none(monkeypatch):
    monkeypatch.setattr(dp.yf, "Ticker", BrokenTicker)
    monkeypatch.setattr(dp, "_chart_json", lambda *a, **k: payload())
    assert dp.get_live_quote("RELIANCE") == {"price": 1234.5, "source": "yahoo chart meta"}
    def down(*a, **k): raise ValueError("nope")
    monkeypatch.setattr(dp, "_chart_json", down)
    assert dp.get_live_quote("RELIANCE") is None


def test_api_error_text_names_the_exception_type(monkeypatch):
    main._cache.clear()
    def boom(*a, **k): raise KeyError("tradingPeriods")
    monkeypatch.setattr(main, "fetch_history", boom)
    r = TestClient(main.app).get("/api/snapshot?symbol=ZZZ")
    assert r.status_code == 400 and r.json()["detail"] == "KeyError: 'tradingPeriods'"
